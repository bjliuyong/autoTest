# ✅ 用例通过 — DEMO-PASS-001

- 运行批次：`20261020-194758`
- 判定时间：2026-10-20T19:48:08
- 会话ID：`D0001`

## 一、用例数据（JSON 体表格）

| 字段 | 值 |
| --- | --- |
| `case_id` | DEMO-PASS-001 |
| `run_id` | 20261020-194758 |
| `result` | 通过 |
| `captured_at` | 2026-10-20T19:48:06 |
| `judged_at` | 2026-10-20T19:48:08 |
| `expected.allow_pass` | true |
| `expected.failed_node` | null |
| `actual.allow_pass` | true |
| `actual.failed_node` | null |
| `actual.failed_nodes` | [] |
| `actual.session_id` | D0001 |
| `actual.note` | 出现「旅客[张三]离开通道」 |
| `verdict.passed` | true |
| `verdict.reasons` | 通行结论一致（允许通行） |
| `verdict.expected_allow_pass` | true |
| `verdict.actual_allow_pass` | true |
| `verdict.expected_failed_node` | null |
| `verdict.actual_failed_node` | null |
| `verdict.actual_failed_nodes` | [] |
| `verdict.resolution` | 出现「旅客[张三]离开通道」 |
| `verdict.timed_out` | false |
| `logs.session_id` | D0001 |
| `logs.line_count` | 5 |
| `capture.passenger_name` | 张三 |
| `capture.cert_type` | ID_CARD |
| `capture.cert_no` | 110101199003071234 |
| `capture.gate_id` | G01 |
| `ledger.log_marker` | 0 |
| `artifacts.case_json` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-PASS-001\case.json |
| `artifacts.logs_txt` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-PASS-001\logs.txt |
| `artifacts.report_md` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-PASS-001\report.md |
| `artifacts.report_html` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-PASS-001\report.html |
| `artifacts.photo` | null |

## 二、采集照片

_（本条用例没有携带照片）_

## 三、该旅客相关日志

```text
[流程引擎]创建新会话D0001
[流程引擎]旅客[张三]证件读取成功 证件号=110101199003071234
[证件核验]会话ID[D0001]-节点证件核验开始
[人脸比对]会话ID[D0001]-节点人脸比对通过 相似度=0.93
[通行控制]旅客[张三]离开通道 闸机开门方向=入口
```

## 四、DeepSeek Harness 分析

_（用例通过，未触发分析）_
