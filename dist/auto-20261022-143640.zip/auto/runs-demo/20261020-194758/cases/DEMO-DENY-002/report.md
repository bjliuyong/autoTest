# ✅ 用例通过 — DEMO-DENY-002

- 运行批次：`20261020-194758`
- 判定时间：2026-10-20T19:48:10
- 会话ID：`D0002`

## 一、用例数据（JSON 体表格）

| 字段 | 值 |
| --- | --- |
| `case_id` | DEMO-DENY-002 |
| `run_id` | 20261020-194758 |
| `result` | 通过 |
| `captured_at` | 2026-10-20T19:48:09 |
| `judged_at` | 2026-10-20T19:48:10 |
| `expected.allow_pass` | false |
| `expected.failed_node` | 证件核验 |
| `actual.allow_pass` | false |
| `actual.failed_node` | 证件核验 |
| `actual.failed_nodes` | 证件核验 |
| `actual.session_id` | D0002 |
| `actual.note` | 会话 D0002 节点「证件核验」执行失败 |
| `verdict.passed` | true |
| `verdict.reasons` | 通行结论一致（不允许通行），失败节点一致：证件核验 |
| `verdict.expected_allow_pass` | false |
| `verdict.actual_allow_pass` | false |
| `verdict.expected_failed_node` | 证件核验 |
| `verdict.actual_failed_node` | 证件核验 |
| `verdict.actual_failed_nodes` | 证件核验 |
| `verdict.resolution` | 会话 D0002 节点「证件核验」执行失败 |
| `verdict.timed_out` | false |
| `logs.session_id` | D0002 |
| `logs.line_count` | 3 |
| `capture.passenger_name` | 李四 |
| `capture.cert_type` | ID_CARD |
| `capture.cert_no` | 310101198805124321 |
| `capture.gate_id` | G01 |
| `ledger.log_marker` | 5 |
| `artifacts.case_json` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-DENY-002\case.json |
| `artifacts.logs_txt` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-DENY-002\logs.txt |
| `artifacts.report_md` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-DENY-002\report.md |
| `artifacts.report_html` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-DENY-002\report.html |
| `artifacts.photo` | null |

## 二、采集照片

_（本条用例没有携带照片）_

## 三、该旅客相关日志

```text
[流程引擎]创建新会话D0002
[流程引擎]旅客[李四]证件读取成功 证件号=310101198805124321
[证件核验]会话ID[D0002]-节点证件核验执行失败 原因=证件有效期已过期
```

## 四、DeepSeek Harness 分析

_（用例通过，未触发分析）_
