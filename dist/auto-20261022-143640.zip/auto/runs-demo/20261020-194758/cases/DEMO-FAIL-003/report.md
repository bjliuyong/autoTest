# ❌ 用例不通过 — DEMO-FAIL-003

- 运行批次：`20261020-194758`
- 判定时间：2026-10-20T19:48:12
- 会话ID：`D0003`

## 一、用例数据（JSON 体表格）

| 字段 | 值 |
| --- | --- |
| `case_id` | DEMO-FAIL-003 |
| `run_id` | 20261020-194758 |
| `result` | 不通过 |
| `captured_at` | 2026-10-20T19:48:11 |
| `judged_at` | 2026-10-20T19:48:12 |
| `expected.allow_pass` | true |
| `expected.failed_node` | null |
| `actual.allow_pass` | false |
| `actual.failed_node` | 证件核验 |
| `actual.failed_nodes` | 证件核验 |
| `actual.session_id` | D0003 |
| `actual.note` | 会话 D0003 节点「证件核验」执行失败 |
| `verdict.passed` | false |
| `verdict.reasons` | 通行结论不一致：预期「允许通行」，实际「不允许通行」 |
| `verdict.expected_allow_pass` | true |
| `verdict.actual_allow_pass` | false |
| `verdict.expected_failed_node` | null |
| `verdict.actual_failed_node` | 证件核验 |
| `verdict.actual_failed_nodes` | 证件核验 |
| `verdict.resolution` | 会话 D0003 节点「证件核验」执行失败 |
| `verdict.timed_out` | false |
| `logs.session_id` | D0003 |
| `logs.line_count` | 3 |
| `capture.passenger_name` | 王五 |
| `capture.cert_type` | ID_CARD |
| `capture.cert_no` | 440301199512258765 |
| `capture.gate_id` | G02 |
| `ledger.log_marker` | 9 |
| `artifacts.case_json` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-FAIL-003\case.json |
| `artifacts.logs_txt` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-FAIL-003\logs.txt |
| `artifacts.report_md` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-FAIL-003\report.md |
| `artifacts.report_html` | D:\Work\Project\auto\runs-demo\20261020-194758\cases\DEMO-FAIL-003\report.html |
| `artifacts.photo` | null |

## 二、采集照片

_（本条用例没有携带照片）_

## 三、该旅客相关日志

```text
[流程引擎]创建新会话D0003
[流程引擎]旅客[王五]证件读取成功 证件号=440301199512258765
[证件核验]会话ID[D0003]-节点证件核验执行失败 原因=证件有效期已过期 expire=2020-01-01
```

## 四、DeepSeek Harness 分析

_已跳过分析：DeepSeek Harness 分析未启用_
